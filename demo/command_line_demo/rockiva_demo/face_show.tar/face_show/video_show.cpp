#include "video_show.h"

videoshow::videoshow(QWidget *parent)
    : QWidget(parent)
{
    setAutoFillBackground(true);
}

void videoshow::paintEvent(QPaintEvent *){
    try{
        QPainter painter(this);

        if(!img.isNull()){
			QImage image((QString)("/home/mixtile/share/rockiva/demo/command_line_demo/install/rockiva_rk3588_linux/rockiva_demo/images/out/frames/") + "0000.jpg");
            painter.drawImage(QPointF(0,0),image);
            // painter.drawImage(QPointF(0,0),img);
        }

    }catch(...){}
}
