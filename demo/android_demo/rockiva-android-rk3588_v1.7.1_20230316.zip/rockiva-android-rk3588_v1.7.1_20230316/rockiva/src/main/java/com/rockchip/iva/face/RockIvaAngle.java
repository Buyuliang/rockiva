package com.rockchip.iva.face;

public class RockIvaAngle {
    public int pitch;             /* 俯仰角,表示绕x轴旋转角度 */
    public int yaw;               /* 偏航角,表示绕y轴旋转角度 */
    public int roll;              /* 翻滚角,表示绕z轴旋转角度 */
}
